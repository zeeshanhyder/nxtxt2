let _dgram = require('dgram');
let ip = require('ip');




function getIPAddress(){
    return ip.address();
}

function getDomainAddress(address) {
    let domain = [];
    domain = address.split(".");
    domain.pop();
    domain = domain.join("."); 
    return domain; //return it back
}

function getBroadCastAddress(domain){
    return `${domain}.255`;
}


let bcst_tx = null;
let bcst_rx = null;

/*
 *
 *  The constants below are signals that are exchanged by a node when registering on the network,
 *  for the discovery of an already active messaging server (websockets) to connect with
 */ 

 // This signalling message tests for active server
 const BROADCAST_MESSAGE_REQUEST_MSG_SERVER = 0;
 // This is an acknowledgement sent by the server, if present
 const BROADCAST_MESSAGE_ACK_MSG_SERVER = 1;


 // broadcast sender port
 const BCST_TX_PORT = 7080;
 // broadcast receiver port
 const BCST_RX_PORT = 7081;
 

 // Websockets Server Flag to denote we are running websockets server
 let WS_SERVER_FLAG = false;

 // our host address on network
 let HOST_ADDR = getIPAddress();
 let DOMAIN_ADDR = getDomainAddress(HOST_ADDR);
 // broadcast address on the network
 const BCST_ADDR = getBroadCastAddress(DOMAIN_ADDR);





/*
 * @param port <Int> 
 * This function returns the Broadcast Sender object with which you can
 *  broadcast messages on the network
 */ 
 function getBCST_TX(port) {
     let broadcast = _dgram.createSocket('udp4');
    broadcast.on("listening", function () {
        broadcast.setBroadcast(true);
    });
    broadcast.bind(port);
    console.log(`* Broadcast Transmitter running on: ${HOST_ADDR}:${port}`);
    
    return broadcast;
}







 /*
 * @param port <Int> 
 * This function returns the Broadcast Sender object with which you can
 *  reeceive broadcast messages on the network
 */

 function getBCST_RX(port) {
     let broadcast =  _dgram.createSocket('udp4');
    // Listen for emission of the "message" event.
    broadcast.on("listening", function () {
        console.log(`* Broadcast Receiver running on: ${HOST_ADDR}:${port}`);
        // Create a transmitter to send broadcasts to other servers
        bcst_tx = getBCST_TX(BCST_TX_PORT);
        
        // first broadcast message to check for available servers
        let message = new Buffer(BROADCAST_MESSAGE_REQUEST_MSG_SERVER);
        bcst_tx.send(message, 0, message.length, port, BCST_ADDR);
    });
    broadcast.on('message', function (msg, rinfo) {
        if(rinfo.address === HOST_ADDR){
            // no need to reply to our own broadcasts
            return;
        }
        switch(msg){
            // If someone is requesting information about Messaging server
            case BROADCAST_MESSAGE_REQUEST_MSG_SERVER:
                // If we are indeed messaging server
                if(WS_SERVER_FLAG){
                    // Send acknowledgement. Yes this is messaging server.
                    let response = new Buffer(BROADCAST_MESSAGE_ACK_MSG_SERVER);
                    bcst_tx.send(response,0,response.length, BCST_TX_PORT, BCST_ADDR);
                }
                break;
            case BROADCAST_MESSAGE_ACK_MSG_SERVER:
                console.log(`    -> Websockets Server discovered at: ${rinfo.address}`);
                console.log(`    -> Closing local Messaging Server.`);
                WS_SERVER_FLAG = false;
                //server.close();
                break;
            default:
                console.log("Broadcast Receiver received unrecognized message!");
                break;
        }
    });
    // Bind to port
    broadcast.bind(port);

    return broadcast;
}


// broadcast receiver
bcst_rx = getBCST_RX(BCST_RX_PORT);

if(bcst_rx){
    console.log("Broadcast Server running!");
}
